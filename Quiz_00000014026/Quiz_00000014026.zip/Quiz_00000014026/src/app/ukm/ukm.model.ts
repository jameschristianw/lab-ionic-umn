export class UKM{
    constructor(
        public id: number,
        public title: string,
        public desc: string,
    ) {}
}