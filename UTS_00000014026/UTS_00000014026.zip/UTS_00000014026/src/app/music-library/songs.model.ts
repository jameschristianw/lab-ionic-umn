export class Songs{
    constructor(
        public id: string,
        public title: string,
        public minute: number,
        public second: number,
        public fav: boolean,
    ){}
}