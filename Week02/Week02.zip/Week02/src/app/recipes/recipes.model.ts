export interface Recipes{
  id: string;
  title: string;
  imageUrl: string;
  ingredients: string[];
}